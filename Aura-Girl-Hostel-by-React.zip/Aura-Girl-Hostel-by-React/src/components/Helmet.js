import React from "react";
import {Helmet} from "react-helmet";

const Helmet = () => {
  return (
    <div>
            <Helmet>
                
                <title>My Title</title>
                <meta name="keywords" content="Aura Girls Hostel Responsive web, Bootstrap Web Template, Flat Web template, Android Compatible web page, 
Smartphone Compatible web template" />
            </Helmet>
            
        </div>
  )
}
export default Helmet;
